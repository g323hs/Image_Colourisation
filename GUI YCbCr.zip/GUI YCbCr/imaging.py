from typing import Dict, Tuple

from PIL import Image, ImageDraw

Point = Tuple[int, int]
RGB = Tuple[int, int, int]


def load_image(path: str) -> Image.Image:
    """Load an image from disk."""
    img = Image.open(path)

    # Normalize uncommon modes for consistent behavior.
    if img.mode not in ("RGB", "RGBA", "L"):
        img = img.convert("RGB")

    return img


def to_grayscale(img: Image.Image) -> Image.Image:
    """Convert an image to a grayscale ('L') image.

    If the image has an alpha channel, it is composited over white
    before conversion to avoid unexpected dark edges.
    """
    if img.mode == "RGBA":
        background = Image.new("RGBA", img.size, (255, 255, 255, 255))
        img = Image.alpha_composite(background, img).convert("RGB")
    return img.convert("L")


def _to_rgb_no_alpha(img: Image.Image) -> Image.Image:
    """Convert to RGB, compositing alpha over white if needed."""
    if img.mode == "RGBA":
        background = Image.new("RGBA", img.size, (255, 255, 255, 255))
        return Image.alpha_composite(background, img).convert("RGB")
    if img.mode != "RGB":
        return img.convert("RGB")
    return img


def get_point_color(original_img: Image.Image, x: int, y: int) -> RGB:
    """Get the original RGB color at (x, y)."""
    rgb = _to_rgb_no_alpha(original_img)
    r, g, b = rgb.getpixel((x, y))
    return int(r), int(g), int(b)


def grayscale_with_color_points(
    original_img: Image.Image,
    point_colors: Dict[Point, RGB],
    radius: int = 3,
) -> Image.Image:
    """Create an RGB image: grayscale background + colored seed points."""
    rgb = _to_rgb_no_alpha(original_img)
    gray_rgb = rgb.convert("L").convert("RGB")

    if not point_colors:
        return gray_rgb

    draw = ImageDraw.Draw(gray_rgb)
    w, h = gray_rgb.size
    r = max(0, int(radius))

    for (x, y), color in point_colors.items():
        if not (0 <= x < w and 0 <= y < h):
            continue

        if r <= 0:
            gray_rgb.putpixel((x, y), color)
        else:
            left = x - r
            top = y - r
            right = x + r
            bottom = y + r
            draw.ellipse([left, top, right, bottom], fill=color, outline=None)

    return gray_rgb
