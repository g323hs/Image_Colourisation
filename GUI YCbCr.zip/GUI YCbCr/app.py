import os
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from typing import Dict, Optional, Tuple
from urllib.parse import unquote, urlparse

from PIL import Image, ImageTk

try:
    from PIL import ImageGrab
    IMAGEGRAB_AVAILABLE = True
except Exception:
    IMAGEGRAB_AVAILABLE = False

try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    DND_AVAILABLE = True
except Exception:
    DND_AVAILABLE = False
    DND_FILES = None
    TkinterDnD = None

from imaging import get_point_color, grayscale_with_color_points, load_image, to_grayscale
from reconstruct import reconstruct_rkhs_colorization
from sampling import random_points, uniform_grid_points

Point = Tuple[int, int]
RGB = Tuple[int, int, int]


def _best_resample():
    try:
        return Image.Resampling.LANCZOS  # Pillow >= 9
    except AttributeError:
        return Image.LANCZOS  # Older Pillow


RESAMPLE = _best_resample()


def rgb_to_hex(c: RGB) -> str:
    r, g, b = c
    return f"#{r:02x}{g:02x}{b:02x}"


class ImagePanel(ttk.LabelFrame):
    """A resizable panel that displays a PIL image."""

    def __init__(self, master, title: str):
        super().__init__(master, text=title, padding=6)
        self._label = ttk.Label(self)
        self._label.pack(fill=tk.BOTH, expand=True)
        self._pil: Optional[Image.Image] = None
        self._photo: Optional[ImageTk.PhotoImage] = None
        self.bind("<Configure>", lambda e: self._render())

    def set_image(self, img: Optional[Image.Image]) -> None:
        self._pil = img
        self._render()

    def _render(self) -> None:
        if self._pil is None:
            self._label.configure(image="", text="")
            return

        w = max(1, self.winfo_width() - 12)
        h = max(1, self.winfo_height() - 28)

        iw, ih = self._pil.size
        scale = min(w / iw, h / ih)
        scale = max(0.01, scale)

        new_w = max(1, int(iw * scale))
        new_h = max(1, int(ih * scale))

        img = self._pil.resize((new_w, new_h), RESAMPLE)
        self._photo = ImageTk.PhotoImage(img)
        self._label.configure(image=self._photo)


class GrayscaleReconstructApp:
    def __init__(self) -> None:
        self.root = TkinterDnD.Tk() if DND_AVAILABLE else tk.Tk()
        self.root.title("RKHS Image Colorization - GUI")
        self.root.geometry("1240x760")

        # Images
        self.original_img: Optional[Image.Image] = None
        self.gray_img: Optional[Image.Image] = None
        self.reconstructed_img: Optional[Image.Image] = None

        # Points and their original RGB colors
        self.point_colors: Dict[Point, RGB] = {}

        # UI variables
        self.status_var = tk.StringVar(value="Drop an image, paste it, or open a file to begin.")
        self.marker_radius = tk.IntVar(value=3)

        # Canvas view modes for the sampling page
        self.canvas_view = tk.StringVar(value="Grayscale")

        # Sampling vars
        self.sampling_mode = tk.StringVar(value="Uniform Grid")
        self.uniform_nx = tk.StringVar(value="10")
        self.uniform_ny = tk.StringVar(value="10")
        self.random_n = tk.StringVar(value="200")
        self.random_seed = tk.StringVar(value="")

        # Manual interaction: add vs delete (toggle)
        self.delete_mode = tk.BooleanVar(value=False)

        # Reconstruction vars
        # We define phi (not the full kernel). The kernel is fixed to a Gaussian-product structure.
        self.phi_choice = tk.StringVar(value="Exp")
        self.sigma_spatial = tk.StringVar(value="100.0")
        self.sigma_intensity = tk.StringVar(value="100.0")
        self.p_power = tk.StringVar(value="0.5")
        self.delta = tk.StringVar(value="2e-4")
        self.batch_size = tk.StringVar(value="5000")
        self.clip_output = tk.BooleanVar(value=True)

        self._reconstruct_thread: Optional[threading.Thread] = None

        # Sampling canvas display state
        self._display_scale: float = 1.0
        self._display_offset: Tuple[int, int] = (0, 0)
        self._canvas_photo: Optional[ImageTk.PhotoImage] = None

        self._build_ui()
        self._bind_shortcuts()

    def run(self) -> None:
        self.root.mainloop()

    # ---------------- UI layout ----------------

    def _build_ui(self) -> None:
        # Toolbar
        toolbar = ttk.Frame(self.root, padding=(8, 6))
        toolbar.pack(side=tk.TOP, fill=tk.X)

        ttk.Button(toolbar, text="Open Image...", command=self.open_image_dialog).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(toolbar, text="Paste Image", command=self.paste_image).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(toolbar, text="Save Grayscale (With Points)...", command=self.save_grayscale_with_points).pack(
            side=tk.LEFT, padx=(0, 6)
        )

        ttk.Separator(toolbar, orient="vertical").pack(side=tk.LEFT, fill=tk.Y, padx=8)

        ttk.Button(toolbar, text="Save Reconstructed...", command=self.save_reconstructed).pack(side=tk.LEFT, padx=(0, 6))

        # Notebook with two pages
        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

        self.page_sampling = ttk.Frame(self.nb)
        self.page_reconstruct = ttk.Frame(self.nb)

        self.nb.add(self.page_sampling, text="Sampling")
        self.nb.add(self.page_reconstruct, text="Reconstruct")

        self._build_sampling_page()
        self._build_reconstruct_page()

        # Status bar
        status = ttk.Frame(self.root, padding=(8, 4))
        status.pack(side=tk.BOTTOM, fill=tk.X)
        ttk.Label(status, textvariable=self.status_var).pack(side=tk.LEFT)

    # ---------------- Sampling page ----------------

    def _build_sampling_page(self) -> None:
        main = ttk.Frame(self.page_sampling, padding=6)
        main.pack(fill=tk.BOTH, expand=True)

        left = ttk.Frame(main)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.canvas = tk.Canvas(left, bg="#222222", highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)

        right = ttk.Frame(main, width=360)
        right.pack(side=tk.RIGHT, fill=tk.Y)
        right.pack_propagate(False)

        info = ttk.LabelFrame(right, text="Info", padding=10)
        info.pack(fill=tk.X, pady=(0, 10))
        self.info_label = ttk.Label(info, text="No image loaded.", justify="left")
        self.info_label.pack(anchor="w")

        view = ttk.LabelFrame(right, text="Canvas View", padding=10)
        view.pack(fill=tk.X, pady=(0, 10))

        ttk.Radiobutton(
            view,
            text="Grayscale",
            variable=self.canvas_view,
            value="Grayscale",
            command=self._render_sampling_canvas,
        ).pack(anchor="w")
        ttk.Radiobutton(
            view,
            text="Original",
            variable=self.canvas_view,
            value="Original",
            command=self._render_sampling_canvas,
        ).pack(anchor="w")
        ttk.Radiobutton(
            view,
            text="Grayscale + Marks",
            variable=self.canvas_view,
            value="Grayscale + Marks",
            command=self._render_sampling_canvas,
        ).pack(anchor="w")

        points = ttk.LabelFrame(right, text="Point Sampling", padding=10)
        points.pack(fill=tk.BOTH, expand=True)

        ttk.Label(points, text="Sampling Mode:").pack(anchor="w")
        mode_combo = ttk.Combobox(
            points,
            textvariable=self.sampling_mode,
            values=["Uniform Grid", "Random", "Manual (Left Click)"],
            state="readonly",
        )
        mode_combo.pack(fill=tk.X, pady=(4, 10))
        mode_combo.bind("<<ComboboxSelected>>", lambda e: self._on_sampling_mode_change())

        self.uniform_frame = ttk.Frame(points)
        ttk.Label(self.uniform_frame, text="X count (nx):").grid(row=0, column=0, sticky="w", pady=2)
        ttk.Entry(self.uniform_frame, textvariable=self.uniform_nx, width=10).grid(row=0, column=1, sticky="w", pady=2)
        ttk.Label(self.uniform_frame, text="Y count (ny):").grid(row=1, column=0, sticky="w", pady=2)
        ttk.Entry(self.uniform_frame, textvariable=self.uniform_ny, width=10).grid(row=1, column=1, sticky="w", pady=2)

        self.random_frame = ttk.Frame(points)
        ttk.Label(self.random_frame, text="Total points (n):").grid(row=0, column=0, sticky="w", pady=2)
        ttk.Entry(self.random_frame, textvariable=self.random_n, width=10).grid(row=0, column=1, sticky="w", pady=2)
        ttk.Label(self.random_frame, text="Seed (optional):").grid(row=1, column=0, sticky="w", pady=2)
        ttk.Entry(self.random_frame, textvariable=self.random_seed, width=10).grid(row=1, column=1, sticky="w", pady=2)

        self.manual_frame = ttk.Frame(points)
        ttk.Label(
            self.manual_frame,
            text=(
                "Manual mode:\n"
                "- Left click to add points\n"
                "- Toggle Delete mode to remove nearest point with left click"
            ),
            justify="left",
        ).pack(anchor="w", pady=(0, 8))
        ttk.Checkbutton(
            self.manual_frame,
            text="Delete mode (left click removes nearest point)",
            variable=self.delete_mode,
            command=self._update_delete_mode_status,
        ).pack(anchor="w")

        marker_row = ttk.Frame(points)
        marker_row.pack(fill=tk.X, pady=(10, 0))
        ttk.Label(marker_row, text="Marker radius (px):").pack(side=tk.LEFT)
        ttk.Spinbox(
            marker_row,
            from_=0,
            to=30,
            textvariable=self.marker_radius,
            width=6,
            command=self._refresh_views,
        ).pack(side=tk.LEFT, padx=(6, 0))

        action_row = ttk.Frame(points)
        action_row.pack(fill=tk.X, pady=(12, 6))
        self.generate_btn = ttk.Button(action_row, text="Generate Points", command=self.generate_points)
        self.generate_btn.pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(action_row, text="Clear Points", command=self.clear_points).pack(side=tk.LEFT)

        self.count_label = ttk.Label(points, text="Points: 0")
        self.count_label.pack(anchor="w", pady=(10, 0))

        # Bindings
        self.canvas.bind("<Configure>", lambda e: self._render_sampling_canvas())
        self.canvas.bind("<Button-1>", self._on_canvas_left_click)

        # Drag and drop
        if DND_AVAILABLE:
            try:
                self.canvas.drop_target_register(DND_FILES)
                self.canvas.dnd_bind("<<Drop>>", self._on_drop)
                self.status_var.set("Ready. Drop an image, paste it, or open a file.")
            except Exception:
                self.status_var.set("Drag-and-drop initialization failed. You can still open/paste images.")
        else:
            self.status_var.set("Drag-and-drop requires 'tkinterdnd2'. You can still open/paste images.")

        self._on_sampling_mode_change()
        self._render_sampling_canvas()

    # ---------------- Reconstruct page ----------------

    def _build_reconstruct_page(self) -> None:
        main = ttk.Frame(self.page_reconstruct, padding=6)
        main.pack(fill=tk.BOTH, expand=True)

        left = ttk.Frame(main, width=380)
        left.pack(side=tk.LEFT, fill=tk.Y)
        left.pack_propagate(False)

        params = ttk.LabelFrame(left, text="Reconstruction Parameters", padding=10)
        params.pack(fill=tk.BOTH, expand=True)

        # Phi selection
        ttk.Label(params, text="Phi type:").pack(anchor="w")
        phi_combo = ttk.Combobox(
            params,
            textvariable=self.phi_choice,
            values=["Exp", "Wendland C2", "Custom Python Code"],
            state="readonly",
        )
        phi_combo.pack(fill=tk.X, pady=(4, 10))
        phi_combo.bind("<<ComboboxSelected>>", lambda e: self._on_phi_choice_change())

        # Kernel structure reminder
        ttk.Label(
            params,
            text=(
                ""
            ),
            justify="left",
            wraplength=340,
        ).pack(anchor="w", pady=(0, 8))

        grid = ttk.Frame(params)
        grid.pack(fill=tk.X)

        def row(label, var, r):
            ttk.Label(grid, text=label).grid(row=r, column=0, sticky="w", pady=2)
            ttk.Entry(grid, textvariable=var, width=14).grid(row=r, column=1, sticky="w", pady=2)

        row("sigma_spatial:", self.sigma_spatial, 0)
        row("sigma_intensity:", self.sigma_intensity, 1)
        row("p (power):", self.p_power, 2)
        row("delta (regularization):", self.delta, 3)
        

        ttk.Separator(params).pack(fill=tk.X, pady=8)

        # Custom code section (hidden unless custom phi is selected)
        self.custom_code_section = ttk.Frame(params)
        ttk.Label(
            self.custom_code_section,
            text="Custom phi code (define phi(r, params)):",
            wraplength=340,
        ).pack(anchor="w")

        code_frame = ttk.Frame(self.custom_code_section)
        code_frame.pack(fill=tk.BOTH, expand=True, pady=(4, 8))

        self.code_text = tk.Text(code_frame, height=10, wrap="none")
        self.code_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        yscroll = ttk.Scrollbar(code_frame, orient="vertical", command=self.code_text.yview)
        yscroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.code_text.configure(yscrollcommand=yscroll.set)

        default_code = (
            "def phi(r, params):\n"
            "    import numpy as np\n"
            "    # r is a numpy array. Return an array of the same shape.\n"
            "    return np.exp(-r)\n"
        )
        self.code_text.insert("1.0", default_code)

        # Run button row
        btn_row = ttk.Frame(params)
        btn_row.pack(fill=tk.X)
        self.reconstruct_btn = ttk.Button(btn_row, text="Reconstruct", command=self.run_reconstruction)
        self.reconstruct_btn.pack(side=tk.LEFT)

        self.progress = ttk.Progressbar(btn_row, mode="indeterminate")
        self.progress.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(10, 0))

        # Right side: 2x2 image grid
        right = ttk.Frame(main)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(8, 0))

        right.grid_rowconfigure(0, weight=1)
        right.grid_rowconfigure(1, weight=1)
        right.grid_columnconfigure(0, weight=1)
        right.grid_columnconfigure(1, weight=1)

        self.panel_original = ImagePanel(right, "Original")
        self.panel_gray = ImagePanel(right, "Grayscale")
        self.panel_gray_marks = ImagePanel(right, "Grayscale + Colored Marks")
        self.panel_reconstructed = ImagePanel(right, "Reconstructed")

        self.panel_original.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
        self.panel_gray.grid(row=0, column=1, sticky="nsew", padx=6, pady=6)
        self.panel_gray_marks.grid(row=1, column=0, sticky="nsew", padx=6, pady=6)
        self.panel_reconstructed.grid(row=1, column=1, sticky="nsew", padx=6, pady=6)

        self._on_phi_choice_change()
        self._refresh_views()

    def _bind_shortcuts(self) -> None:
        self.root.bind("<Control-v>", lambda e: self.paste_image())
        self.root.bind("<Command-v>", lambda e: self.paste_image())  # macOS

    # ---------------- View refresh ----------------

    def _refresh_views(self) -> None:
        # Update reconstruct page panels
        if self.original_img is None:
            self.panel_original.set_image(None)
            self.panel_gray.set_image(None)
            self.panel_gray_marks.set_image(None)
            self.panel_reconstructed.set_image(None)
        else:
            self.panel_original.set_image(self._get_display_original())
            self.panel_gray.set_image(self.gray_img.convert("RGB") if self.gray_img else None)
            marks = grayscale_with_color_points(
                self.original_img, self.point_colors, radius=int(self.marker_radius.get())
            )
            self.panel_gray_marks.set_image(marks)
            self.panel_reconstructed.set_image(self.reconstructed_img)

        # Update sampling canvas
        self._render_sampling_canvas()

    # ---------------- Image IO ----------------

    def _on_drop(self, event) -> None:
        try:
            paths = self.root.tk.splitlist(event.data)
        except Exception:
            paths = [event.data]
        if not paths:
            return
        path = self._normalize_path(paths[0])
        if path:
            self.load_image_from_path(path)

    def _normalize_path(self, path: str) -> str:
        path = path.strip()
        if path.startswith("file://"):
            try:
                parsed = urlparse(path)
                path = unquote(parsed.path)
                if sys.platform.startswith("win") and path.startswith("/"):
                    path = path.lstrip("/")
            except Exception:
                pass
        return path

    def open_image_dialog(self) -> None:
        filetypes = [
            ("Image files", "*.png *.jpg *.jpeg *.bmp *.gif *.tiff *.tif *.webp"),
            ("All files", "*.*"),
        ]
        path = filedialog.askopenfilename(title="Open Image", filetypes=filetypes)
        if path:
            self.load_image_from_path(path)

    def paste_image(self) -> None:
        if not IMAGEGRAB_AVAILABLE:
            messagebox.showwarning(
                "Clipboard Not Available",
                "PIL.ImageGrab is not available in this environment. Try drag-and-drop or use 'Open Image...'.",
            )
            return
        try:
            data = ImageGrab.grabclipboard()
        except Exception as e:
            messagebox.showwarning(
                "Paste Failed",
                f"Failed to read clipboard:\n{e}\n\nTry drag-and-drop or use 'Open Image...'.",
            )
            return

        if data is None:
            messagebox.showinfo("Clipboard Empty", "Clipboard does not contain an image or file path.")
            return

        if isinstance(data, Image.Image):
            self.load_image_from_pil(data)
            return

        if isinstance(data, (list, tuple)) and data:
            p = self._normalize_path(str(data[0]))
            if os.path.isfile(p):
                self.load_image_from_path(p)
                return

        if isinstance(data, str):
            p = self._normalize_path(data)
            if os.path.isfile(p):
                self.load_image_from_path(p)
                return

        messagebox.showinfo("Unsupported Clipboard Content", "Clipboard content is not a supported image format.")

    def load_image_from_path(self, path: str) -> None:
        if not os.path.isfile(path):
            messagebox.showerror("File Not Found", f"File does not exist:\n{path}")
            return
        try:
            img = load_image(path)
        except Exception as e:
            messagebox.showerror("Load Failed", f"Failed to load image:\n{e}")
            return
        self.load_image_from_pil(img)
        self.status_var.set(f"Loaded: {os.path.basename(path)}")

    def load_image_from_pil(self, img: Image.Image) -> None:
        self.original_img = img
        self.gray_img = to_grayscale(img)
        self.reconstructed_img = None
        self.point_colors = {}
        self.delete_mode.set(False)
        self._update_info_label()
        self._update_points_label()
        self._refresh_views()

    def save_grayscale_with_points(self) -> None:
        if self.original_img is None:
            messagebox.showinfo("No Image", "Load an image first.")
            return
        path = filedialog.asksaveasfilename(
            title="Save Grayscale Image (With Colored Points)",
            defaultextension=".png",
            filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg *.jpeg"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            out = grayscale_with_color_points(
                self.original_img,
                self.point_colors,
                radius=int(self.marker_radius.get()),
            )
            out.save(path)
        except Exception as e:
            messagebox.showerror("Save Failed", f"Failed to save image:\n{e}")
            return
        self.status_var.set(f"Saved: {os.path.basename(path)}")

    def save_reconstructed(self) -> None:
        if self.reconstructed_img is None:
            messagebox.showinfo("No Reconstruction", "Run reconstruction first.")
            return
        path = filedialog.asksaveasfilename(
            title="Save Reconstructed Image",
            defaultextension=".png",
            filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg *.jpeg"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            self.reconstructed_img.save(path)
        except Exception as e:
            messagebox.showerror("Save Failed", f"Failed to save image:\n{e}")
            return
        self.status_var.set(f"Saved: {os.path.basename(path)}")

    # ---------------- Sampling logic ----------------

    def _update_info_label(self) -> None:
        if self.original_img is None:
            self.info_label.configure(text="No image loaded.")
            return
        w, h = self.original_img.size
        self.info_label.configure(text=f"Size: {w} x {h}\nMode: {self.original_img.mode}")

    def _update_points_label(self) -> None:
        self.count_label.configure(text=f"Points: {len(self.point_colors)}")

    def clear_points(self) -> None:
        self.point_colors = {}
        self.reconstructed_img = None
        self._update_points_label()
        self._refresh_views()
        self.status_var.set("Points cleared.")

    def generate_points(self) -> None:
        if self.original_img is None:
            messagebox.showinfo("No Image", "Load an image first.")
            return

        w, h = self.original_img.size
        mode = self.sampling_mode.get()

        try:
            if mode == "Uniform Grid":
                nx = int(self.uniform_nx.get().strip())
                ny = int(self.uniform_ny.get().strip())
                pts = uniform_grid_points(w, h, nx, ny)
                self._set_points_from_list(pts)
            elif mode == "Random":
                n = int(self.random_n.get().strip())
                seed_str = self.random_seed.get().strip()
                seed = int(seed_str) if seed_str else None
                pts = random_points(w, h, n, seed=seed)
                self._set_points_from_list(pts)
            else:
                return
        except Exception as e:
            messagebox.showerror("Sampling Error", f"Failed to generate points:\n{e}")
            return

        self.reconstructed_img = None
        self._update_points_label()
        self._refresh_views()
        self.status_var.set(f"Generated {len(self.point_colors)} points.")

    def _set_points_from_list(self, pts) -> None:
        if self.original_img is None:
            return
        w, h = self.original_img.size
        new_dict: Dict[Point, RGB] = {}
        for x, y in pts:
            x = max(0, min(w - 1, int(x)))
            y = max(0, min(h - 1, int(y)))
            p = (x, y)
            if p not in new_dict:
                new_dict[p] = get_point_color(self.original_img, x, y)
        self.point_colors = new_dict

    def _on_sampling_mode_change(self) -> None:
        for f in (self.uniform_frame, self.random_frame, self.manual_frame):
            f.pack_forget()

        mode = self.sampling_mode.get()
        if mode == "Uniform Grid":
            self.uniform_frame.pack(fill=tk.X, pady=(0, 10))
            self.generate_btn.configure(state="normal")
            self.delete_mode.set(False)
        elif mode == "Random":
            self.random_frame.pack(fill=tk.X, pady=(0, 10))
            self.generate_btn.configure(state="normal")
            self.delete_mode.set(False)
        else:
            self.manual_frame.pack(fill=tk.X, pady=(0, 10))
            self.generate_btn.configure(state="disabled")
            self._update_delete_mode_status()

        self._update_points_label()
        self._render_sampling_canvas()

    def _update_delete_mode_status(self) -> None:
        if self.sampling_mode.get() != "Manual (Left Click)":
            self.delete_mode.set(False)
            return
        self.status_var.set(
            "Delete mode ON: left click removes nearest point."
            if self.delete_mode.get()
            else "Delete mode OFF: left click adds points."
        )

    def _get_display_original(self) -> Optional[Image.Image]:
        if self.original_img is None:
            return None
        img = self.original_img
        if img.mode == "RGBA":
            background = Image.new("RGBA", img.size, (30, 30, 30, 255))
            img = Image.alpha_composite(background, img).convert("RGB")
        elif img.mode != "RGB":
            img = img.convert("RGB")
        return img

    def _render_sampling_canvas(self) -> None:
        self.canvas.delete("all")

        if self.original_img is None or self.gray_img is None:
            self._display_scale = 1.0
            self._display_offset = (0, 0)
            msg = "Drop an image here\nor use Open/Paste."
            self.canvas.create_text(
                self.canvas.winfo_width() // 2,
                self.canvas.winfo_height() // 2,
                text=msg,
                fill="white",
                font=("Arial", 14),
                justify="center",
            )
            return

        # Choose display image for canvas
        if self.canvas_view.get() == "Original":
            display_img = self._get_display_original()
            if display_img is None:
                return
        else:
            # "Grayscale" or "Grayscale + Marks"
            display_img = self.gray_img.convert("RGB")

        cw = max(1, self.canvas.winfo_width())
        ch = max(1, self.canvas.winfo_height())
        iw, ih = display_img.size

        scale = min(cw / iw, ch / ih)
        scale = max(0.05, min(10.0, scale))

        new_w = max(1, int(iw * scale))
        new_h = max(1, int(ih * scale))
        resized = display_img.resize((new_w, new_h), RESAMPLE)

        self._canvas_photo = ImageTk.PhotoImage(resized)
        offset_x = (cw - new_w) // 2
        offset_y = (ch - new_h) // 2

        self._display_scale = scale
        self._display_offset = (offset_x, offset_y)

        self.canvas.create_image(offset_x, offset_y, anchor="nw", image=self._canvas_photo)

        # Draw points only in "Grayscale + Marks" view (per requirement)
        if self.canvas_view.get() == "Grayscale + Marks":
            self._draw_points_on_canvas()

    def _draw_points_on_canvas(self) -> None:
        if self.original_img is None or not self.point_colors:
            return

        offset_x, offset_y = self._display_offset
        scale = self._display_scale
        base_r = max(1, int(self.marker_radius.get()))
        r = max(2, int(base_r * scale))

        for (x, y), color in self.point_colors.items():
            cx = offset_x + x * scale
            cy = offset_y + y * scale
            col = rgb_to_hex(color)
            self.canvas.create_oval(cx - r, cy - r, cx + r, cy + r, fill=col, outline="white", width=1)

    def _canvas_to_image(self, canvas_x: int, canvas_y: int) -> Optional[Point]:
        if self.original_img is None:
            return None

        offset_x, offset_y = self._display_offset
        scale = self._display_scale

        x = (canvas_x - offset_x) / scale
        y = (canvas_y - offset_y) / scale

        w, h = self.original_img.size
        if x < 0 or y < 0 or x >= w or y >= h:
            return None
        return int(round(x)), int(round(y))

    def _on_canvas_left_click(self, event) -> None:
        if self.original_img is None:
            return
        if self.sampling_mode.get() != "Manual (Left Click)":
            return

        p = self._canvas_to_image(event.x, event.y)
        if p is None:
            return

        x, y = p
        w, h = self.original_img.size
        x = max(0, min(w - 1, x))
        y = max(0, min(h - 1, y))
        pt = (x, y)

        if self.delete_mode.get():
            removed = self._remove_nearest_point(x, y, tolerance_px=15)
            if removed:
                self.status_var.set(f"Removed point at {removed}.")
            else:
                self.status_var.set("No point close enough to remove.")
        else:
            if pt in self.point_colors:
                self.status_var.set("Point already exists; not added.")
            else:
                self.point_colors[pt] = get_point_color(self.original_img, x, y)
                self.status_var.set(f"Added point at {pt}.")

        self.reconstructed_img = None
        self._update_points_label()
        self._refresh_views()

    def _remove_nearest_point(self, x: int, y: int, tolerance_px: int = 15) -> Optional[Point]:
        if not self.point_colors:
            return None

        tol2 = float(tolerance_px * tolerance_px)
        best_pt: Optional[Point] = None
        best_d2 = float("inf")

        for (px, py) in self.point_colors.keys():
            dx = px - x
            dy = py - y
            d2 = dx * dx + dy * dy
            if d2 < best_d2:
                best_d2 = d2
                best_pt = (px, py)

        if best_pt is not None and best_d2 <= tol2:
            self.point_colors.pop(best_pt, None)
            return best_pt

        return None

    # ---------------- Reconstruction ----------------

    def _on_phi_choice_change(self) -> None:
        is_custom = (self.phi_choice.get() == "Custom Python Code")
        if is_custom:
            if not self.custom_code_section.winfo_ismapped():
                self.custom_code_section.pack(fill=tk.BOTH, expand=True, pady=(0, 8))
        else:
            if self.custom_code_section.winfo_ismapped():
                self.custom_code_section.pack_forget()

    def _get_kernel_params(self) -> Dict[str, float]:
        return {
            "sigma_spatial": float(self.sigma_spatial.get()),
            "sigma_intensity": float(self.sigma_intensity.get()),
            "p": float(self.p_power.get()),
        }

    def run_reconstruction(self) -> None:
        if self.original_img is None or self.gray_img is None:
            messagebox.showinfo("No Image", "Load an image first.")
            return
        if not self.point_colors:
            messagebox.showinfo("No Points", "Add or generate seed points first.")
            return
        if self._reconstruct_thread is not None and self._reconstruct_thread.is_alive():
            messagebox.showinfo("Busy", "Reconstruction is already running.")
            return

        try:
            phi_mode = self.phi_choice.get()
            params = self._get_kernel_params()
            delta = float(self.delta.get())
            batch_size = int(float(self.batch_size.get()))
            clip = bool(self.clip_output.get())
            code = self.code_text.get("1.0", "end").strip() if phi_mode == "Custom Python Code" else None
        except Exception as e:
            messagebox.showerror("Invalid Parameters", f"Please check the parameter values.\n\n{e}")
            return

        # Start worker thread
        self.progress.start(10)
        self.reconstruct_btn.configure(state="disabled")
        self.status_var.set("Running reconstruction...")

        def worker():
            try:
                img = reconstruct_rkhs_colorization(
                    original_img=self.original_img,
                    gray_img=self.gray_img,
                    point_colors=self.point_colors,
                    phi_mode=phi_mode,
                    kernel_params=params,
                    delta=delta,
                    custom_phi_code=code,
                    batch_size=batch_size,
                    clip_to_uint8=clip,
                )
                self._on_reconstruction_done(img, None)
            except Exception as err:
                self._on_reconstruction_done(None, err)

        self._reconstruct_thread = threading.Thread(target=worker, daemon=True)
        self._reconstruct_thread.start()

    def _on_reconstruction_done(self, img: Optional[Image.Image], err: Optional[Exception]) -> None:
        def finish():
            self.progress.stop()
            self.reconstruct_btn.configure(state="normal")
            if err is not None:
                messagebox.showerror("Reconstruction Failed", str(err))
                self.status_var.set("Reconstruction failed.")
                return
            self.reconstructed_img = img
            self.panel_reconstructed.set_image(self.reconstructed_img)
            self.status_var.set("Reconstruction finished.")
        self.root.after(0, finish)
