import os
import time
import json
import argparse
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize

from PIL import Image
from imaging import get_point_color, to_grayscale, load_image
from sampling import random_points, uniform_grid_points
from reconstruct import reconstruct_rkhs_colorization
try:
    from skimage.metrics import structural_similarity as skimage_ssim
except Exception:
    skimage_ssim = None

# Try to import image_difference_score if available, otherwise provide fallbacks
try:
    import image_difference_score as ids
    from image_difference_score import pixelwise_difference
except Exception:
    ids = None

    def pixelwise_difference(a_path, b_path):
        a = Image.open(a_path).convert("RGB")
        b = Image.open(b_path).convert("RGB")
        aa = np.asarray(a, dtype=np.float32)
        bb = np.asarray(b, dtype=np.float32)
        # mean absolute difference normalized to [0,1]
        return float(np.mean(np.abs(aa - bb)) / 255.0)

    def _simple_ssim(a_path, b_path):
        # fallback: use 1 - normalized MSE as a rough proxy (not real SSIM)
        a = Image.open(a_path).convert("L")
        b = Image.open(b_path).convert("L")
        aa = np.asarray(a, dtype=np.float32) / 255.0
        bb = np.asarray(b, dtype=np.float32) / 255.0
        mse = np.mean((aa - bb) ** 2)
        return max(0.0, 1.0 - mse)

    class ids:  # simple namespace replacement
        @staticmethod
        def ssim_difference(a, b):
            return _simple_ssim(a, b)


def _pil_to_gray_array(img: Image.Image) -> np.ndarray:
    return np.asarray(img.convert("L"), dtype=np.float32) / 255.0


def _pil_to_rgb_array(img: Image.Image) -> np.ndarray:
    return np.asarray(img.convert("RGB"), dtype=np.float32) / 255.0


def _compute_ssim(img_a, img_b):
    """Compute SSIM between two PIL images. Returns SSIM in [0,1]."""
    if skimage_ssim is not None:
        a = _pil_to_gray_array(img_a)
        b = _pil_to_gray_array(img_b)
        # skimage returns ssim and optionally full map depending on kwargs
        try:
            s = skimage_ssim(a, b, data_range=1.0)
            return float(s)
        except Exception:
            # fallback
            pass
    # fallback proxy: 1 - MSE
    a = _pil_to_gray_array(img_a)
    b = _pil_to_gray_array(img_b)
    mse = float(np.mean((a - b) ** 2))
    return max(0.0, 1.0 - mse)


def _compute_pixelwise_diff(img_a, img_b):
    a = _pil_to_rgb_array(img_a)
    b = _pil_to_rgb_array(img_b)
    return float(np.mean(np.abs(a - b)))  # in [0,1]


def colourise_process(image_path, save_path_folder, n=1, point_gen_method='random', sigma1=20.0, sigma2=100.0, p=0.5, delta=1e-10, phi_method='gaussian', save_to_disk=True, point_colors=None, debug=False):
    """
    Minimal wrapper that matches the expected external `colourise_process` signature
    but uses the repository's `reconstruct_rkhs_colorization` implementation.

    It will:
    - load the image
    - generate seed points (random or uniform)
    - sample original colours at seed points
    - call `reconstruct_rkhs_colorization` and save `colourised.png` into `save_path_folder`
    """
    os.makedirs(save_path_folder, exist_ok=True)
    # image_path may be a file path or a PIL.Image
    if isinstance(image_path, Image.Image):
        img = image_path
    else:
        img = load_image(image_path)
    w, h = img.size

    # generate or use provided points
    if point_colors is None:
        if point_gen_method == 'random':
            pts = random_points(w, h, n)
        else:
            # fallback to a uniform grid with nx x ny where n ~ nx*ny
            nx = int(max(1, np.sqrt(n)))
            ny = int(max(1, np.ceil(n / nx)))
            pts = uniform_grid_points(w, h, nx, ny)[:n]

        # sample colors
        point_colors = {p: get_point_color(img, p[0], p[1]) for p in pts}

    # prepare inputs for reconstruct
    gray = to_grayscale(img)

    # map phi method names to reconstruct's choices
    phi_map = {
        'gaussian': 'Exp',
        'wendland': 'Wendland C2',
    }
    phi_choice = phi_map.get(str(phi_method).lower(), 'Exp')

    kernel_params = {'sigma_spatial': float(sigma1), 'sigma_intensity': float(sigma2), 'p': float(p)}

    out_img = reconstruct_rkhs_colorization(img, gray, point_colors, phi_choice, kernel_params, float(delta))

    out_path = os.path.join(save_path_folder, 'colourised.png')
    if save_to_disk:
        os.makedirs(save_path_folder, exist_ok=True)
        out_img.save(out_path)
        if debug:
            print(f"Saved colourised image to {out_path}")
        return out_path
    else:
        return out_img


def get_ssim_score_ish(params, image_path, save_path_folder, phi_method='gaussian', n=1, point_colors=None):
    sigma1, sigma2, p, delta = params
    os.makedirs(save_path_folder, exist_ok=True)
    # produce colourised image in-memory
    out_img = colourise_process(image_path,
                                save_path_folder,
                                n,
                                point_gen_method='random',
                                sigma1=sigma1,
                                sigma2=sigma2,
                                p=p,
                                delta=delta,
                                phi_method=phi_method,
                                save_to_disk=False,
                                point_colors=point_colors)

    # load original image as PIL.Image if needed
    if isinstance(image_path, Image.Image):
        orig = image_path
    else:
        orig = load_image(image_path)

    # compute SSIM-like score in-memory
    ssim_score = _compute_ssim(orig, out_img)
    # return minimisable score (lower is better)
    return 1.0 - float(ssim_score)


def get_pixelwise_difference(params, image_path, save_path_folder, phi_method='gaussian', n=1, point_colors=None):
    sigma1, sigma2, p, delta = params
    os.makedirs(save_path_folder, exist_ok=True)
    out_img = colourise_process(image_path,
                                save_path_folder,
                                n,
                                point_gen_method='random',
                                sigma1=sigma1,
                                sigma2=sigma2,
                                p=p,
                                delta=delta,
                                phi_method=phi_method,
                                save_to_disk=False,
                                point_colors=point_colors)

    if isinstance(image_path, Image.Image):
        orig = image_path
    else:
        orig = load_image(image_path)

    pixel_diff = _compute_pixelwise_diff(orig, out_img)
    return float(pixel_diff)


def run_optimisation(image_path,
                     save_path_folder,
                     num_points,
                     initial_guess=None,
                     phi_methods=None,
                     score_functions=None,
                     maxiter=100,
                     verbose=True,
                     point_colors=None):
    if initial_guess is None:
        initial_guess = [10.0, 10.0, 0.5, 2.0e-7]
    if phi_methods is None:
        phi_methods = ['gaussian', 'wendland']
    if score_functions is None:
        score_functions = [get_ssim_score_ish, get_pixelwise_difference]

    os.makedirs(save_path_folder, exist_ok=True)
    results = []

    for score_function in score_functions:
        for phi_method in phi_methods:
            if verbose:
                print(f"Optimising for score {score_function.__name__} with phi {phi_method}")

            # wrapper to pass the extra args in the expected order
            # args: image_path, save_path_folder, phi_method, num_points, point_colors
            args = (image_path, save_path_folder, phi_method, num_points, point_colors)

            start = time.time()
            # wrap the score function to record loss history per function evaluation
            history = []

            def wrapped_score(params, *fargs):
                val = score_function(params, *fargs)
                history.append(float(val))
                return val

            result = minimize(wrapped_score,
                              x0=np.array(initial_guess, dtype=float),
                              args=args,
                              method='Nelder-Mead',
                              options={'maxiter': maxiter, 'xatol': 1e-4, 'fatol': 1e-4})
            duration = time.time() - start

            # result.fun is the minimized value; for SSIM we minimized 1-ssim, so lower is better
            score_value = result.fun
            if verbose:
                print(f"Finished in {duration:.1f}s: score={score_value:.6g}, params={result.x}")

            # save final colourised image for inspection
            out_subdir = os.path.join(save_path_folder, f"{score_function.__name__}_{phi_method}")
            os.makedirs(out_subdir, exist_ok=True)
            colourise_process(image_path,
                              out_subdir,
                              num_points,
                              point_gen_method='random',
                              sigma1=result.x[0],
                              sigma2=result.x[1],
                              p=result.x[2],
                              delta=result.x[3],
                              phi_method=phi_method,
                              debug=False)

            # plot and save loss history (loss vs evaluation index)
            try:
                import matplotlib.pyplot as mplt
                if history:
                    fig_path = os.path.join(out_subdir, 'loss_curve.png')
                    mplt.figure()
                    mplt.plot(range(1, len(history) + 1), history, marker='o')
                    mplt.xlabel('Function evaluation')
                    mplt.ylabel('Loss')
                    mplt.title(f'Loss curve: {score_function.__name__} / {phi_method}')
                    mplt.grid(True)
                    mplt.tight_layout()
                    mplt.savefig(fig_path)
                    mplt.close()
                    if verbose:
                        print(f"Saved loss curve to {fig_path}")
            except Exception:
                # plotting is optional; ignore errors here
                pass

            results.append({
                'score_function': score_function.__name__,
                'phi_method': phi_method,
                'score': float(score_value),
                'params': [float(x) for x in result.x],
                'nit': int(result.nit) if hasattr(result, 'nit') else None,
                'success': bool(result.success),
                'message': str(result.message)
            })

    # save results JSON
    results_path = os.path.join(save_path_folder, 'optimisation_results.json')
    with open(results_path, 'w') as fh:
        json.dump({'image': image_path, 'results': results}, fh, indent=2)

    if verbose:
        print(f"Saved results to {results_path}")

    return results


def parse_args():
    p = argparse.ArgumentParser(description='Optimise colourisation parameters')
    p.add_argument('--image', '-i', required=True, help='Path to input image')
    p.add_argument('--out', '-o', required=True, help='Output folder to save results')
    p.add_argument('--num-points', '-n', type=int, default=50, help='Number of seed points')
    p.add_argument('--maxiter', type=int, default=100, help='Max iterations for optimiser')
    p.add_argument('--phi', type=str, default='gaussian,wendland', help='Comma separated phi methods')
    p.add_argument('--scores', type=str, default='ssim,pixel', help='Comma separated score functions (ssim,pixel)')
    return p.parse_args()


if __name__ == '__main__':
    args = parse_args()
    image_path = args.image
    save_path_folder = args.out
    num_points = args.num_points
    maxiter = args.maxiter

    phi_methods = [x.strip() for x in args.phi.split(',') if x.strip()]
    score_choices = [x.strip().lower() for x in args.scores.split(',') if x.strip()]

    score_functions = []
    for s in score_choices:
        if s == 'ssim':
            score_functions.append(get_ssim_score_ish)
        elif s == 'pixel':
            score_functions.append(get_pixelwise_difference)

    # run optimisation
    run_optimisation(image_path=image_path,
                     save_path_folder=save_path_folder,
                     num_points=num_points,
                     initial_guess=None,
                     phi_methods=phi_methods,
                     score_functions=score_functions,
                     maxiter=maxiter,
                     verbose=True)
