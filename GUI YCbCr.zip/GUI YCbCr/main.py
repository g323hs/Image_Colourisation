from app import GrayscaleReconstructApp


def main() -> None:
    app = GrayscaleReconstructApp()
    app.run()


if __name__ == "__main__":
    main()
