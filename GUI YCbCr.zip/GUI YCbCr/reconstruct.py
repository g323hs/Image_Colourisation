from typing import Callable, Dict, Optional, Tuple

import numpy as np
from PIL import Image

Point = Tuple[int, int]
RGB = Tuple[int, int, int]


def _rgb_image_to_numpy(img: Image.Image) -> np.ndarray:
    """Convert a PIL image to an RGB uint8 numpy array (H, W, 3)."""
    if img.mode == "RGBA":
        bg = Image.new("RGBA", img.size, (255, 255, 255, 255))
        img = Image.alpha_composite(bg, img).convert("RGB")
    elif img.mode != "RGB":
        img = img.convert("RGB")
    return np.asarray(img, dtype=np.uint8)


def _gray_image_to_numpy(img: Image.Image) -> np.ndarray:
    """Convert a PIL image to grayscale float32 numpy array (H, W) in [0, 255]."""
    if img.mode != "L":
        img = img.convert("L")
    return np.asarray(img, dtype=np.float32)


# ---------------- Phi functions ----------------

def phi_exp(r: np.ndarray, params: Dict[str, float]) -> np.ndarray:
    """Exponential phi(r) = exp(-r)."""
    return np.exp(-r)


def phi_wendland_c2(r: np.ndarray, params: Dict[str, float]) -> np.ndarray:
    """Wendland C2 compactly supported phi(r) = ((1-r)_+)^4 (4r + 1)."""
    t = np.maximum(1.0 - r, 0.0)
    return (t ** 4) * (4.0 * r + 1.0)


def compile_custom_phi(code: str) -> Callable[[np.ndarray, Dict[str, float]], np.ndarray]:
    """Compile user-provided Python code into a phi(r, params) function.

    The code must define a function named 'phi'. Recommended signature:

        def phi(r, params):
            import numpy as np
            return np.exp(-r)

    Notes:
        - This executes arbitrary Python code via exec(). Only use code you trust.
        - 'np' is provided in the execution namespace.
    """
    namespace: Dict[str, object] = {"np": np}
    exec(code, namespace, namespace)  # nosec - user-controlled
    fn = namespace.get("phi")
    if fn is None or not callable(fn):
        raise ValueError("Custom phi code must define a callable function named 'phi'.")
    return fn  # type: ignore[return-value]


def _eval_phi(phi_fn: Callable, r: np.ndarray, params: Dict[str, float]) -> np.ndarray:
    """Evaluate phi safely and validate the shape."""
    try:
        out = phi_fn(r, params)
    except TypeError:
        # Allow legacy signature phi(r)
        out = phi_fn(r)

    out = np.asarray(out, dtype=np.float32)
    if out.shape != r.shape:
        raise ValueError(f"phi(r) returned shape {out.shape}, expected {r.shape}.")
    return out


# ---------------- Kernel construction ----------------

def kernel_matrix_gaussian_product_with_phi(
    A_xy: np.ndarray,
    A_g: np.ndarray,
    B_xy: np.ndarray,
    B_g: np.ndarray,
    phi_fn: Callable,
    params: Dict[str, float],
    img_height: int = 1,
    img_width: int = 1,
) -> np.ndarray:
    """Compute kernel matrix using a fixed 'Gaussian product' structure and a selectable phi.

    We always use the product form (note-inspired):

        k(x,y) = phi( ||x-y||^2 / sigma_spatial ) * phi( |g(x)-g(y)|^p / sigma_intensity )

    where phi is chosen from:
        - exp(-r)
        - Wendland C2: ((1-r)_+)^4 (4r + 1)
        - custom code

    Args:
        A_xy: (NA,2) float32 array of xy positions.
        A_g:  (NA,) float32 array of grayscale intensities.
        B_xy: (NB,2) float32 array of xy positions.
        B_g:  (NB,) float32 array of grayscale intensities.
        phi_fn: callable phi(r, params) or phi(r)
        params: sigma_spatial, sigma_intensity, p
        img_height: Image height for diagonal normalization
        img_width: Image width for diagonal normalization

    Returns:
        K: (NA, NB) float32 array.
    """
    sigma_spatial = float(params.get("sigma_spatial", 100.0))
    sigma_intensity = float(params.get("sigma_intensity", 100.0))
    p = float(params.get("p", 1.0))

    # Normalize sigma_spatial by image diagonal length
    diagonal = np.sqrt(float(img_height) ** 2 + float(img_width) ** 2)
    sigma_spatial = sigma_spatial * diagonal
    # Normalize sigma_intensity by 255^p
    sigma_intensity = sigma_intensity * (255.0 ** p)

    eps = 1e-12
    sigma_spatial = max(sigma_spatial, eps)
    sigma_intensity = max(sigma_intensity, eps)

    # Broadcasted differences
    dx = A_xy[:, 0:1] - B_xy[:, 0][None, :]
    dy = A_xy[:, 1:2] - B_xy[:, 1][None, :]
    dist2 = dx * dx + dy * dy
    dg = A_g[:, None] - B_g[None, :]

    r_sp = dist2 / sigma_spatial
    r_g = (np.abs(dg) ** p) / sigma_intensity

    k_sp = _eval_phi(phi_fn, r_sp.astype(np.float32, copy=False), params)
    k_g = _eval_phi(phi_fn, r_g.astype(np.float32, copy=False), params)

    return (k_sp * k_g).astype(np.float32, copy=False)


# ---------- RGB <-> YCbCr  ----------
def rgb_to_ycbcr_pixels(rgb_arr: np.ndarray) -> np.ndarray:
    """
    Convert an array of RGB colors (...,3) in [0,255] to YCbCr (...,3) in [0,255]
    using BT.601 (Cb/Cr offset +128).
    """
    r = rgb_arr[..., 0].astype(np.float64)
    g = rgb_arr[..., 1].astype(np.float64)
    b = rgb_arr[..., 2].astype(np.float64)
    Y = 0.299 * r + 0.587 * g + 0.114 * b
    Cb = -0.168736 * r - 0.331264 * g + 0.5 * b + 128.0
    Cr = 0.5 * r - 0.418688 * g - 0.081312 * b + 128.0
    return np.stack([Y, Cb, Cr], axis=-1)


def ycbcr_to_rgb_pixels(ycbcr_arr: np.ndarray) -> np.ndarray:
    """
    Convert YCbCr (...,3) in [0,255] (Cb/Cr with +128 offset) to RGB (...,3) in [0,255].
    Clips to [0,255] and returns uint8.
    """
    Y = ycbcr_arr[..., 0].astype(np.float64)
    Cb = (ycbcr_arr[..., 1].astype(np.float64) - 128.0)
    Cr = (ycbcr_arr[..., 2].astype(np.float64) - 128.0)
    R = Y + 1.402 * Cr
    G = Y - 0.344136 * Cb - 0.714136 * Cr
    B = Y + 1.772 * Cb
    out = np.stack([R, G, B], axis=-1)
    out = np.clip(out, 0.0, 255.0).astype(np.uint8)
    return out


# ---------------- Reconstruction ----------------

def reconstruct_rkhs_colorization(
    original_img: Image.Image,
    gray_img: Image.Image,
    point_colors: Dict[Point, RGB],
    phi_mode: str,
    kernel_params: Dict[str, float],
    delta: float,
    custom_phi_code: Optional[str] = None,
    batch_size: int = 5000,
    clip_to_uint8: bool = True,
) -> Image.Image:
    """Reconstruct a full color image from sparse colored points using RKHS regularized least squares.

    This version fixes luminance (Y) and reconstructs chrominance channels (Cb, Cr) in YCbCr space.
    """
    if not point_colors:
        raise ValueError("No seed points available. Please add points first.")
    if delta < 0:
        raise ValueError("delta must be >= 0.")

    # Pick phi function
    phi_mode = str(phi_mode).strip()
    if phi_mode == "Exp":
        phi_fn = phi_exp
    elif phi_mode == "Wendland C2":
        phi_fn = phi_wendland_c2
    elif phi_mode == "Custom Python Code":
        if not custom_phi_code or not custom_phi_code.strip():
            raise ValueError("Custom phi mode selected, but no phi code provided.")
        phi_fn = compile_custom_phi(custom_phi_code)
    else:
        raise ValueError(f"Unknown phi mode: {phi_mode}")

    # Convert images to arrays
    _ = _rgb_image_to_numpy(original_img)  # keep for potential future use
    gray = _gray_image_to_numpy(gray_img)  # dtype float32, values in [0,255]

    h, w = gray.shape
    seeds = list(point_colors.keys())
    n = len(seeds)

    # Seed coordinate array (n,2) and Y values (n,)
    D_xy = np.array([[float(x), float(y)] for (x, y) in seeds], dtype=np.float32)
    D_y = np.array([float(gray[y, x]) for (x, y) in seeds], dtype=np.float32)  # use Y as grayscale

    # Seed colors: convert provided RGB seeds -> YCbCr and take Cb/Cr as targets
    seed_rgb = np.array([point_colors[(x, y)] for (x, y) in seeds], dtype=np.float64)  # shape (n,3)
    seed_ycbcr = rgb_to_ycbcr_pixels(seed_rgb)  # (n,3)
    f_cb = seed_ycbcr[:, 1].astype(np.float64)  # targets for Cb (0-255)
    f_cr = seed_ycbcr[:, 2].astype(np.float64)  # targets for Cr (0-255)

    # Build K_D (n,n) using Y channel (gray) for intensity part
    K_D = kernel_matrix_gaussian_product_with_phi(
        D_xy, D_y, D_xy, D_y, phi_fn, kernel_params, img_height=h, img_width=w
    ).astype(np.float64)

    # Regularization: (K_D + delta*n*I)
    reg = float(delta) * float(n)
    K_reg = K_D + reg * np.eye(n, dtype=np.float64)

    # Solve for coefficients for Cb and Cr separately
    a_cb = np.linalg.solve(K_reg, f_cb)
    a_cr = np.linalg.solve(K_reg, f_cr)

    # Reconstruct all pixels in batches: predict Cb and Cr
    m = w * h
    out_cb = np.zeros((m,), dtype=np.float64)
    out_cr = np.zeros((m,), dtype=np.float64)

    # Flatten pixel grid coordinates and Y (use same order as kernel expects)
    xs = np.tile(np.arange(w, dtype=np.float32), h)
    ys = np.repeat(np.arange(h, dtype=np.float32), w)
    y_flat = gray.reshape(-1).astype(np.float32)

    bs = max(1, int(batch_size))
    for start in range(0, m, bs):
        end = min(m, start + bs)
        A_xy = np.stack([xs[start:end], ys[start:end]], axis=1).astype(np.float32)
        A_g = y_flat[start:end].astype(np.float32)

        K = kernel_matrix_gaussian_product_with_phi(
            A_xy, A_g, D_xy, D_y, phi_fn, kernel_params, img_height=h, img_width=w
        )  # shape (batch, n)

        out_cb[start:end] = K.astype(np.float64) @ a_cb
        out_cr[start:end] = K.astype(np.float64) @ a_cr

    # Combine Y + predicted Cb/Cr into YCbCr array and convert to RGB
    ycbcr_full = np.stack([y_flat, out_cb, out_cr], axis=1)  # shape (m,3) in 0-255 range
    rgb_full = ycbcr_to_rgb_pixels(ycbcr_full)  # returns uint8 (m,3)

    out_img = rgb_full.reshape((h, w, 3))

    if clip_to_uint8:
        return Image.fromarray(out_img, mode="RGB")
    else:
        return Image.fromarray(out_img.astype(np.uint8), mode="RGB")