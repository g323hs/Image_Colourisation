from __future__ import annotations

import os
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from typing import List, Optional, Tuple
from urllib.parse import unquote, urlparse

from PIL import Image, ImageTk

try:
    from PIL import ImageGrab
    IMAGEGRAB_AVAILABLE = True
except Exception:
    IMAGEGRAB_AVAILABLE = False

try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    DND_AVAILABLE = True
except Exception:
    DND_AVAILABLE = False
    DND_FILES = None
    TkinterDnD = None

from imaging import load_image, to_grayscale
from sampling import random_points, uniform_grid_points

Point = Tuple[int, int]


def _best_resample():
    try:
        return Image.Resampling.LANCZOS  # Pillow >= 9
    except AttributeError:
        return Image.LANCZOS  # Older Pillow


RESAMPLE = _best_resample()


class GrayscaleSamplerApp:
    def __init__(self) -> None:
        self.root = TkinterDnD.Tk() if DND_AVAILABLE else tk.Tk()
        self.root.title("Grayscale Converter + Point Sampler")
        self.root.geometry("1100x700")

        self.original_img: Optional[Image.Image] = None
        self.gray_img: Optional[Image.Image] = None

        self.view_mode = tk.StringVar(value="grayscale")  # "grayscale" or "original"

        self.points: List[Point] = []
        self.sampling_mode = tk.StringVar(value="Uniform Grid")

        self.uniform_nx = tk.StringVar(value="10")
        self.uniform_ny = tk.StringVar(value="10")

        self.random_n = tk.StringVar(value="200")
        self.random_seed = tk.StringVar(value="")

        self.status_var = tk.StringVar(value="Drop an image, paste it, or open a file to begin.")

        self._display_scale: float = 1.0
        self._display_offset: Tuple[int, int] = (0, 0)
        self._photo: Optional[ImageTk.PhotoImage] = None

        self._build_ui()
        self._bind_shortcuts()

    def run(self) -> None:
        self.root.mainloop()

    def _build_ui(self) -> None:
        # Top toolbar
        toolbar = ttk.Frame(self.root, padding=(8, 6))
        toolbar.pack(side=tk.TOP, fill=tk.X)

        ttk.Button(toolbar, text="Open Image...", command=self.open_image_dialog).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(toolbar, text="Paste Image", command=self.paste_image).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(toolbar, text="Save Grayscale...", command=self.save_grayscale).pack(side=tk.LEFT, padx=(0, 12))

        ttk.Separator(toolbar, orient="vertical").pack(side=tk.LEFT, fill=tk.Y, padx=8)

        ttk.Button(toolbar, text="Clear Points", command=self.clear_points).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(toolbar, text="Export Points (CSV)...", command=self.export_points_csv).pack(side=tk.LEFT)

        # Main layout
        main = ttk.Frame(self.root, padding=8)
        main.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        # Left: Canvas
        left = ttk.Frame(main)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.canvas = tk.Canvas(left, bg="#222222", highlightthickness=0)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Right: Controls
        right = ttk.Frame(main, width=320)
        right.pack(side=tk.RIGHT, fill=tk.Y)
        right.pack_propagate(False)

        view_frame = ttk.LabelFrame(right, text="View", padding=10)
        view_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Radiobutton(view_frame, text="Show Grayscale", variable=self.view_mode, value="grayscale",
                        command=self._render).pack(anchor="w")
        ttk.Radiobutton(view_frame, text="Show Original", variable=self.view_mode, value="original",
                        command=self._render).pack(anchor="w")

        info_frame = ttk.LabelFrame(right, text="Info", padding=10)
        info_frame.pack(fill=tk.X, pady=(0, 10))

        self.info_label = ttk.Label(info_frame, text="No image loaded.", justify="left")
        self.info_label.pack(anchor="w")

        points_frame = ttk.LabelFrame(right, text="Point Sampling", padding=10)
        points_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(points_frame, text="Sampling Mode:").pack(anchor="w")
        mode_combo = ttk.Combobox(points_frame, textvariable=self.sampling_mode,
                                  values=["Uniform Grid", "Random", "Manual (Mouse Click)"],
                                  state="readonly")
        mode_combo.pack(fill=tk.X, pady=(4, 10))
        mode_combo.bind("<<ComboboxSelected>>", lambda e: self._on_mode_change())

        # Uniform controls
        self.uniform_frame = ttk.Frame(points_frame)
        ttk.Label(self.uniform_frame, text="X count (nx):").grid(row=0, column=0, sticky="w", pady=2)
        ttk.Entry(self.uniform_frame, textvariable=self.uniform_nx, width=10).grid(row=0, column=1, sticky="w", pady=2)

        ttk.Label(self.uniform_frame, text="Y count (ny):").grid(row=1, column=0, sticky="w", pady=2)
        ttk.Entry(self.uniform_frame, textvariable=self.uniform_ny, width=10).grid(row=1, column=1, sticky="w", pady=2)

        # Random controls
        self.random_frame = ttk.Frame(points_frame)
        ttk.Label(self.random_frame, text="Total points (n):").grid(row=0, column=0, sticky="w", pady=2)
        ttk.Entry(self.random_frame, textvariable=self.random_n, width=10).grid(row=0, column=1, sticky="w", pady=2)

        ttk.Label(self.random_frame, text="Seed (optional):").grid(row=1, column=0, sticky="w", pady=2)
        ttk.Entry(self.random_frame, textvariable=self.random_seed, width=10).grid(row=1, column=1, sticky="w", pady=2)

        # Manual controls
        self.manual_frame = ttk.Frame(points_frame)
        manual_text = (
            "Manual mode:\n"
            "- Left click to add a point\n"
            "- Right click to remove the nearest point\n"
        )
        ttk.Label(self.manual_frame, text=manual_text, justify="left").pack(anchor="w")

        # Action buttons
        btn_row = ttk.Frame(points_frame)
        btn_row.pack(fill=tk.X, pady=(12, 6))

        self.generate_btn = ttk.Button(btn_row, text="Generate Points", command=self.generate_points)
        self.generate_btn.pack(side=tk.LEFT)

        self.count_label = ttk.Label(points_frame, text="Points: 0")
        self.count_label.pack(anchor="w", pady=(6, 0))

        # Status bar
        status = ttk.Frame(self.root, padding=(8, 4))
        status.pack(side=tk.BOTTOM, fill=tk.X)
        ttk.Label(status, textvariable=self.status_var).pack(side=tk.LEFT)

        # Canvas bindings
        self.canvas.bind("<Configure>", lambda e: self._render())
        self.canvas.bind("<Button-1>", self._on_left_click)
        self.canvas.bind("<Button-3>", self._on_right_click)

        # Drag-and-drop setup
        if DND_AVAILABLE:
            try:
                self.canvas.drop_target_register(DND_FILES)
                self.canvas.dnd_bind("<<Drop>>", self._on_drop)
                self.status_var.set("Ready. Drop an image, paste it, or open a file.")
            except Exception:
                self.status_var.set("Drag-and-drop initialization failed. You can still open/paste images.")
        else:
            self.status_var.set("Drag-and-drop requires 'tkinterdnd2'. You can still open/paste images.")

        self._on_mode_change()
        self._render()

    def _bind_shortcuts(self) -> None:
        # Clipboard paste shortcuts
        self.root.bind("<Control-v>", lambda e: self.paste_image())
        self.root.bind("<Command-v>", lambda e: self.paste_image())  # macOS

    def _on_mode_change(self) -> None:
        for f in (self.uniform_frame, self.random_frame, self.manual_frame):
            f.pack_forget()

        mode = self.sampling_mode.get()
        if mode == "Uniform Grid":
            self.uniform_frame.pack(fill=tk.X, pady=(0, 10))
            self.generate_btn.configure(state="normal")
        elif mode == "Random":
            self.random_frame.pack(fill=tk.X, pady=(0, 10))
            self.generate_btn.configure(state="normal")
        else:
            self.manual_frame.pack(fill=tk.X, pady=(0, 10))
            self.generate_btn.configure(state="disabled")

        self._update_count_label()

    def _on_drop(self, event) -> None:
        # tkinterdnd2 returns a Tcl list; splitlist handles braces and spaces.
        try:
            paths = self.root.tk.splitlist(event.data)
        except Exception:
            paths = [event.data]

        if not paths:
            return

        path = paths[0]
        path = self._normalize_path(path)

        if not path:
            return

        self.load_image_from_path(path)

    def _normalize_path(self, path: str) -> str:
        path = path.strip()

        # Handle file:// URIs
        if path.startswith("file://"):
            try:
                parsed = urlparse(path)
                path = unquote(parsed.path)
                if sys.platform.startswith("win") and path.startswith("/"):
                    # On Windows, file:///C:/... may parse with a leading "/"
                    path = path.lstrip("/")
            except Exception:
                pass

        return path

    def open_image_dialog(self) -> None:
        filetypes = [
            ("Image files", "*.png *.jpg *.jpeg *.bmp *.gif *.tiff *.tif *.webp"),
            ("All files", "*.*"),
        ]
        path = filedialog.askopenfilename(title="Open Image", filetypes=filetypes)
        if path:
            self.load_image_from_path(path)

    def paste_image(self) -> None:
        if not IMAGEGRAB_AVAILABLE:
            messagebox.showwarning(
                "Clipboard Not Available",
                "PIL.ImageGrab is not available in this environment.\n"
                "Try drag-and-drop or use 'Open Image...'."
            )
            return

        try:
            data = ImageGrab.grabclipboard()
        except Exception as e:
            messagebox.showwarning(
                "Paste Failed",
                f"Failed to read clipboard:\n{e}\n\nTry drag-and-drop or use 'Open Image...'."
            )
            return

        if data is None:
            messagebox.showinfo("Clipboard Empty", "Clipboard does not contain an image or file path.")
            return

        # If clipboard contains an image
        if isinstance(data, Image.Image):
            self.load_image_from_pil(data)
            return

        # If clipboard contains file paths (e.g., copied file in Explorer)
        if isinstance(data, (list, tuple)) and data:
            path = self._normalize_path(str(data[0]))
            if os.path.isfile(path):
                self.load_image_from_path(path)
                return

        # If clipboard contains a string path
        if isinstance(data, str):
            path = self._normalize_path(data)
            if os.path.isfile(path):
                self.load_image_from_path(path)
                return

        messagebox.showinfo("Unsupported Clipboard Content", "Clipboard content is not a supported image format.")

    def load_image_from_path(self, path: str) -> None:
        if not os.path.isfile(path):
            messagebox.showerror("File Not Found", f"File does not exist:\n{path}")
            return

        try:
            img = load_image(path)
        except Exception as e:
            messagebox.showerror("Load Failed", f"Failed to load image:\n{e}")
            return

        self.load_image_from_pil(img)
        self.status_var.set(f"Loaded: {os.path.basename(path)}")

    def load_image_from_pil(self, img: Image.Image) -> None:
        self.original_img = img
        self.gray_img = to_grayscale(img)

        self.points = []
        self._update_info_label()
        self._update_count_label()
        self._render()

    def save_grayscale(self) -> None:
        if self.gray_img is None:
            messagebox.showinfo("No Image", "Load an image first.")
            return

        filetypes = [
            ("PNG", "*.png"),
            ("JPEG", "*.jpg *.jpeg"),
            ("BMP", "*.bmp"),
            ("TIFF", "*.tiff *.tif"),
            ("All files", "*.*"),
        ]
        path = filedialog.asksaveasfilename(
            title="Save Grayscale Image",
            defaultextension=".png",
            filetypes=filetypes
        )
        if not path:
            return

        try:
            self.gray_img.save(path)
        except Exception as e:
            messagebox.showerror("Save Failed", f"Failed to save grayscale image:\n{e}")
            return

        self.status_var.set(f"Saved grayscale: {os.path.basename(path)}")

    def export_points_csv(self) -> None:
        if self.original_img is None:
            messagebox.showinfo("No Image", "Load an image first.")
            return

        if not self.points:
            messagebox.showinfo("No Points", "No points to export.")
            return

        path = filedialog.asksaveasfilename(
            title="Export Points as CSV",
            defaultextension=".csv",
            filetypes=[("CSV", "*.csv"), ("All files", "*.*")]
        )
        if not path:
            return

        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write("x,y\n")
                for x, y in self.points:
                    f.write(f"{x},{y}\n")
        except Exception as e:
            messagebox.showerror("Export Failed", f"Failed to export points:\n{e}")
            return

        self.status_var.set(f"Exported points: {os.path.basename(path)}")

    def clear_points(self) -> None:
        self.points = []
        self._update_count_label()
        self._render()

    def generate_points(self) -> None:
        if self.original_img is None:
            messagebox.showinfo("No Image", "Load an image first.")
            return

        w, h = self.original_img.size
        mode = self.sampling_mode.get()

        try:
            if mode == "Uniform Grid":
                nx = int(self.uniform_nx.get().strip())
                ny = int(self.uniform_ny.get().strip())
                self.points = uniform_grid_points(w, h, nx, ny)

            elif mode == "Random":
                n = int(self.random_n.get().strip())
                seed_str = self.random_seed.get().strip()
                seed = int(seed_str) if seed_str else None
                self.points = random_points(w, h, n, seed=seed)

            else:
                # Manual mode has no "generate" action
                return

        except Exception as e:
            messagebox.showerror("Sampling Error", f"Failed to generate points:\n{e}")
            return

        self._update_count_label()
        self._render()
        self.status_var.set(f"Generated {len(self.points)} points.")

    def _update_info_label(self) -> None:
        if self.original_img is None:
            self.info_label.configure(text="No image loaded.")
            return

        w, h = self.original_img.size
        mode = self.original_img.mode
        self.info_label.configure(text=f"Size: {w} x {h}\nMode: {mode}")

    def _update_count_label(self) -> None:
        self.count_label.configure(text=f"Points: {len(self.points)}")

    def _render(self) -> None:
        self.canvas.delete("all")

        if self.original_img is None:
            self._display_scale = 1.0
            self._display_offset = (0, 0)
            msg_lines = [
                "Drop an image here",
                "or click 'Open Image...' / 'Paste Image'.",
            ]
            if not DND_AVAILABLE:
                msg_lines.append("")
                msg_lines.append("Note: Drag-and-drop requires 'tkinterdnd2'.")

            self.canvas.create_text(
                self.canvas.winfo_width() // 2,
                self.canvas.winfo_height() // 2,
                text="\n".join(msg_lines),
                fill="white",
                font=("Arial", 14),
                justify="center"
            )
            return

        display_img = self._get_display_image()
        if display_img is None:
            return

        cw = max(1, self.canvas.winfo_width())
        ch = max(1, self.canvas.winfo_height())

        iw, ih = display_img.size
        scale = min(cw / iw, ch / ih)
        scale = max(0.05, min(10.0, scale))

        new_w = max(1, int(iw * scale))
        new_h = max(1, int(ih * scale))

        resized = display_img.resize((new_w, new_h), RESAMPLE)
        self._photo = ImageTk.PhotoImage(resized)

        offset_x = (cw - new_w) // 2
        offset_y = (ch - new_h) // 2

        self._display_scale = scale
        self._display_offset = (offset_x, offset_y)

        self.canvas.create_image(offset_x, offset_y, anchor="nw", image=self._photo)

        self._draw_points()
        self._update_info_label()
        self._update_count_label()

    def _get_display_image(self) -> Optional[Image.Image]:
        if self.original_img is None:
            return None

        mode = self.view_mode.get()
        if mode == "original":
            img = self.original_img
            if img.mode == "RGBA":
                # Composite over a dark background for preview
                background = Image.new("RGBA", img.size, (30, 30, 30, 255))
                img = Image.alpha_composite(background, img).convert("RGB")
            elif img.mode != "RGB":
                img = img.convert("RGB")
            return img

        # grayscale
        if self.gray_img is None:
            self.gray_img = to_grayscale(self.original_img)
        return self.gray_img

    def _draw_points(self) -> None:
        if self.original_img is None or not self.points:
            return

        offset_x, offset_y = self._display_offset
        scale = self._display_scale

        # Marker size in canvas pixels
        r = max(2, int(3 * scale))

        for x, y in self.points:
            cx = offset_x + x * scale
            cy = offset_y + y * scale

            # Cross marker
            self.canvas.create_line(cx - r, cy, cx + r, cy, fill="yellow", width=2, tags=("point",))
            self.canvas.create_line(cx, cy - r, cx, cy + r, fill="yellow", width=2, tags=("point",))

    def _canvas_to_image(self, canvas_x: int, canvas_y: int) -> Optional[Point]:
        if self.original_img is None:
            return None

        offset_x, offset_y = self._display_offset
        scale = self._display_scale

        x = (canvas_x - offset_x) / scale
        y = (canvas_y - offset_y) / scale

        w, h = self.original_img.size
        if x < 0 or y < 0 or x >= w or y >= h:
            return None

        return int(round(x)), int(round(y))

    def _on_left_click(self, event) -> None:
        if self.original_img is None:
            return
        if self.sampling_mode.get() != "Manual (Mouse Click)":
            return

        p = self._canvas_to_image(event.x, event.y)
        if p is None:
            return

        x, y = p
        w, h = self.original_img.size
        x = max(0, min(w - 1, x))
        y = max(0, min(h - 1, y))

        self.points.append((x, y))
        self._update_count_label()
        self._render()

    def _on_right_click(self, event) -> None:
        if self.original_img is None:
            return
        if self.sampling_mode.get() != "Manual (Mouse Click)":
            return
        if not self.points:
            return

        p = self._canvas_to_image(event.x, event.y)
        if p is None:
            return

        px, py = p
        idx = self._nearest_point_index(px, py)
        if idx is None:
            return

        self.points.pop(idx)
        self._update_count_label()
        self._render()

    def _nearest_point_index(self, x: int, y: int) -> Optional[int]:
        if not self.points:
            return None

        best_i = 0
        best_d2 = (self.points[0][0] - x) ** 2 + (self.points[0][1] - y) ** 2
        for i in range(1, len(self.points)):
            dx = self.points[i][0] - x
            dy = self.points[i][1] - y
            d2 = dx * dx + dy * dy
            if d2 < best_d2:
                best_d2 = d2
                best_i = i
        return best_i
