from __future__ import annotations

from PIL import Image


def load_image(path: str) -> Image.Image:
    """
    Load an image from disk. Keeps the original mode when possible,
    but ensures a display-friendly mode when needed.
    """
    img = Image.open(path)

    # Normalize uncommon modes for consistent behavior.
    if img.mode not in ("RGB", "RGBA", "L"):
        img = img.convert("RGB")

    return img


def to_grayscale(img: Image.Image) -> Image.Image:
    """
    Convert an image to a grayscale ("L") image.

    If the image has an alpha channel, it is composited over white
    before conversion to avoid unexpected dark edges.
    """
    if img.mode == "RGBA":
        background = Image.new("RGBA", img.size, (255, 255, 255, 255))
        img = Image.alpha_composite(background, img).convert("RGB")

    return img.convert("L")
