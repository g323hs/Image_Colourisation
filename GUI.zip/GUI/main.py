from __future__ import annotations

from app import GrayscaleSamplerApp


def main() -> None:
    app = GrayscaleSamplerApp()
    app.run()


if __name__ == "__main__":
    main()
