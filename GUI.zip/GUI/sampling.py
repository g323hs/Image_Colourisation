from __future__ import annotations

import random
from typing import List, Optional, Tuple

Point = Tuple[int, int]


def uniform_grid_points(width: int, height: int, nx: int, ny: int) -> List[Point]:
    """
    Generate a uniform grid of points over an image.

    Points are placed at the centers of grid cells.
    nx: number of points along X axis
    ny: number of points along Y axis
    """
    if width <= 0 or height <= 0:
        raise ValueError("width and height must be positive.")
    if nx <= 0 or ny <= 0:
        raise ValueError("nx and ny must be positive integers.")

    points: List[Point] = []
    for j in range(ny):
        y = int(round((j + 0.5) * height / ny))
        y = max(0, min(height - 1, y))
        for i in range(nx):
            x = int(round((i + 0.5) * width / nx))
            x = max(0, min(width - 1, x))
            points.append((x, y))
    return points


def random_points(width: int, height: int, n: int, seed: Optional[int] = None) -> List[Point]:
    """
    Generate n random points uniformly distributed over the image.
    """
    if width <= 0 or height <= 0:
        raise ValueError("width and height must be positive.")
    if n <= 0:
        raise ValueError("n must be a positive integer.")

    rng = random.Random(seed)
    return [(rng.randrange(0, width), rng.randrange(0, height)) for _ in range(n)]
